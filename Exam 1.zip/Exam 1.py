# Updated 'students' string with more records
students = """Dalia Sidibe,70,65,80
Malik Sadiq,84,89,93
Ryan Scott,81,70,90
Zuri Mwangi,57,57,62
Omar Ali,90,98,90
Yasmin El-Sayed,78,90,91
Hannah Lee,78,73,78
Noor Khalil,93,90,94
Aaliyah Zahra,54,92,86
David Brown,92,56,64
Amira Salim,69,71,70
Kamilah Diop,82,99,57
Malik Kamara,99,96,100
Fatima Ibrahim,99,80,95
Joshua White,87,84,90
Scarlett Campbell,88,100,89
Ibrahim Farah,77,88,85
Olivia Anderson,73,94,98
Layla Ahmed,72,85,75
Zara Al-Hassan,72,50,63
Hadiya Nasser,63,50,82
Samuel Nelson,85,59,73
Kofi Mensah,57,64,88
Amara Okafor,58,90,78
Zainab Mohammed,77,92,84
Jibril Jabari,77,50,74
Chloe Baker,80,90,91
Aisha Suleiman,73,70,80
Mason Allen,89,98,90
Aria Mitchell,70,72,60
Leila Abdi,76,80,80
Ethan Clark,90,83,80
Anthony Parker,90,96,80
Jacob Walker,75,70,81
Idris Ndlovu,73,77,83
Sanaa Zaki,90,77,85
James Wilson,96,91,86
Michael Smith,79,80,88
Rania Fayed,89,93,79
Amira Tanweer,71,83,98
Layla Khamisi,99,83,91
Grace Taylor,56,62,61
Malik Kamara,80,71,78
Amina Hassan,86,79,87
Nora Evans,98,95,100
Jessica Jones,80,78,83
William Perez,95,90,94
Malik Kamara,81,82,94
Benjamin Adams,84,83,97
Sarah Williams,73,93,71
Jacob Walker,70,84,85
Idris Abubakar,88,77,92
Hala Faris,87,87,98
Amira Toure,94,81,93
Hannah Juma,79,69,78"""

# Step 1: Parse the data
student_records = [line.split(",") for line in students.strip().split("\n")]


# Step 2: Function to calculate the adjusted score and grade
def calculate_grade(exam_scores):
    adjusted_score = max(exam_scores)

    if adjusted_score >= 90:
        grade = "A"
    elif adjusted_score >= 80:
        grade = "B"
    elif adjusted_score >= 70:
        grade = "C"
    else:
        grade = "F"

    return adjusted_score, grade


# Step 3: Formatting and output
print(
    f"{'Full Name'.center(20)} {'Ex1'.center(7)} {'Ex2'.center(7)} {'Ex3'.center(7)} {'Adj.'.center(7)} {'Grade'.center(7)}")
print("=" * 60)

for record in student_records:
    name = record[0].center(20)
    ex1, ex2, ex3 = map(int, record[1:4])
    adjusted_score, grade = calculate_grade([ex1, ex2, ex3])

    print(
        f"{name} {str(ex1).center(7)} {str(ex2).center(7)} {str(ex3).center(7)} {str(adjusted_score).center(7)} {grade.center(7)}")
